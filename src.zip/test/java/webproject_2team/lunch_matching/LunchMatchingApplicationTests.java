package webproject_2team.lunch_matching;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LunchMatchingApplicationTests {

	@Test
	void contextLoads() {
	}

}
